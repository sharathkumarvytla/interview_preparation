-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.32 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for smlcodes
DROP DATABASE IF EXISTS `smlcodes`;
CREATE DATABASE IF NOT EXISTS `smlcodes` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `smlcodes`;

-- Dumping structure for table smlcodes.account
DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `accno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `bal` double DEFAULT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.actor
DROP TABLE IF EXISTS `actor`;
CREATE TABLE IF NOT EXISTS `actor` (
  `mid` int(10) DEFAULT NULL,
  `actorid` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `actorname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`actorid`),
  KEY `FK585A9F550821B2A` (`mid`),
  KEY `FK585A9F578674FF6` (`mid`),
  KEY `FK585A9F59AF2AC60` (`mid`),
  CONSTRAINT `FK585A9F550821B2A` FOREIGN KEY (`mid`) REFERENCES `movie` (`mid`),
  CONSTRAINT `FK585A9F59AF2AC60` FOREIGN KEY (`mid`) REFERENCES `movie` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.address
DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `authId` int(11) DEFAULT NULL,
  `hno` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  KEY `FKBB979BF46BAD728E` (`authId`),
  CONSTRAINT `FKBB979BF46BAD728E` FOREIGN KEY (`authId`) REFERENCES `author` (`authId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.author
DROP TABLE IF EXISTS `author`;
CREATE TABLE IF NOT EXISTS `author` (
  `authId` int(11) NOT NULL AUTO_INCREMENT,
  `authName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`authId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.bank
DROP TABLE IF EXISTS `bank`;
CREATE TABLE IF NOT EXISTS `bank` (
  `accno` int(11) NOT NULL AUTO_INCREMENT,
  `accname` varchar(50) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.bike
DROP TABLE IF EXISTS `bike`;
CREATE TABLE IF NOT EXISTS `bike` (
  `type` varchar(50) DEFAULT NULL,
  `vid` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.book
DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `authId` int(11) DEFAULT NULL,
  `bookId` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bookName` varchar(50) DEFAULT NULL,
  KEY `authId` (`authId`),
  KEY `FK2E3AE9AAD3FC45` (`authId`),
  KEY `bookId` (`bookId`),
  CONSTRAINT `FK2E3AE9AAD3FC45` FOREIGN KEY (`authId`) REFERENCES `author` (`authId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.car
DROP TABLE IF EXISTS `car`;
CREATE TABLE IF NOT EXISTS `car` (
  `CAR_ID` int(10) NOT NULL,
  `NAME` varchar(20) DEFAULT NULL,
  `COLOR` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CAR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.course
DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `courseId` int(11) NOT NULL AUTO_INCREMENT,
  `courseName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`courseId`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.employee
DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `address` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.engine
DROP TABLE IF EXISTS `engine`;
CREATE TABLE IF NOT EXISTS `engine` (
  `CAR_ID` int(10) NOT NULL,
  `size` varchar(20) DEFAULT NULL,
  `MODEL` varchar(20) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`CAR_ID`),
  KEY `FK7A2AEE424A93D311` (`CAR_ID`),
  KEY `FKB297FA42B3A1BD9B` (`CAR_ID`),
  CONSTRAINT `engine_ibfk_1` FOREIGN KEY (`CAR_ID`) REFERENCES `car` (`CAR_ID`),
  CONSTRAINT `FK7A2AEE424A93D311` FOREIGN KEY (`CAR_ID`) REFERENCES `car` (`CAR_ID`),
  CONSTRAINT `FKB297FA42B3A1BD9B` FOREIGN KEY (`CAR_ID`) REFERENCES `car` (`CAR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.hibernate_unique_key
DROP TABLE IF EXISTS `hibernate_unique_key`;
CREATE TABLE IF NOT EXISTS `hibernate_unique_key` (
  `next_hi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.movie
DROP TABLE IF EXISTS `movie`;
CREATE TABLE IF NOT EXISTS `movie` (
  `mid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=503 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.student
DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `studentId` int(11) NOT NULL AUTO_INCREMENT,
  `studentName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`studentId`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.students
DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `fk_course_id` int(11) NOT NULL,
  `fk_student_id` int(11) NOT NULL,
  `FK_student_course_course` int(11) DEFAULT NULL,
  `FK_student_course_student` int(11) DEFAULT NULL,
  PRIMARY KEY (`fk_course_id`,`fk_student_id`),
  KEY `FK6FD1C598AA676C09` (`fk_student_id`),
  KEY `FK6FD1C59811BA0DCB` (`fk_course_id`),
  KEY `FK6FD1C5981B3BE6C7` (`FK_student_course_course`),
  KEY `FK6FD1C598FA0BB005` (`FK_student_course_student`),
  CONSTRAINT `FK6FD1C59811BA0DCB` FOREIGN KEY (`fk_course_id`) REFERENCES `course` (`courseId`),
  CONSTRAINT `FK6FD1C5981B3BE6C7` FOREIGN KEY (`FK_student_course_course`) REFERENCES `course` (`courseId`),
  CONSTRAINT `FK6FD1C598AA676C09` FOREIGN KEY (`fk_student_id`) REFERENCES `student` (`studentId`),
  CONSTRAINT `FK6FD1C598FA0BB005` FOREIGN KEY (`FK_student_course_student`) REFERENCES `student` (`studentId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.studenttable
DROP TABLE IF EXISTS `studenttable`;
CREATE TABLE IF NOT EXISTS `studenttable` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.student_course
DROP TABLE IF EXISTS `student_course`;
CREATE TABLE IF NOT EXISTS `student_course` (
  `COURSE_ID` int(10) NOT NULL,
  `STUDENT_ID` int(10) NOT NULL,
  PRIMARY KEY (`COURSE_ID`,`STUDENT_ID`),
  KEY `FKCB6FBEBFAD895D0F` (`COURSE_ID`),
  KEY `FKCB6FBEBF88820545` (`STUDENT_ID`),
  KEY `FKB0A3729F1E1A78C5` (`COURSE_ID`),
  KEY `FKB0A3729F2A14604F` (`STUDENT_ID`),
  CONSTRAINT `FKB0A3729F1E1A78C5` FOREIGN KEY (`COURSE_ID`) REFERENCES `course` (`courseId`),
  CONSTRAINT `FKB0A3729F2A14604F` FOREIGN KEY (`STUDENT_ID`) REFERENCES `student` (`studentId`),
  CONSTRAINT `fk_c_id` FOREIGN KEY (`COURSE_ID`) REFERENCES `course` (`courseId`),
  CONSTRAINT `fk_s_id` FOREIGN KEY (`STUDENT_ID`) REFERENCES `student` (`studentId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table smlcodes.vehicle
DROP TABLE IF EXISTS `vehicle`;
CREATE TABLE IF NOT EXISTS `vehicle` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `price` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
