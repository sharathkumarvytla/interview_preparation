package nativeSql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class NativeSqlDemo {

	public static void main(String[] args) {
		// 1.Load Configuration
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		// 2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		System.out.println("1.Simple Native SQL\n ========================");
		SQLQuery query1 = session.createSQLQuery("select *from Employee");
		List list1 = query1.list();
		Iterator it1 = list1.iterator();
		while (it1.hasNext()) {
			Object[] ob = (Object[]) it1.next();
			System.out.println(ob[0] + ", " + ob[1] + ", " + ob[2]);
		}

		System.out.println("2.Native SQL with entityQuery\n ========================");
		SQLQuery query2 = session.createSQLQuery("select *from Employee");
		query2.addEntity(EmployeeBo.class);
		List list2 = query2.list();
		Iterator it2 = list2.iterator();
		while (it2.hasNext()) {
			EmployeeBo bo = (EmployeeBo) it2.next();
			System.out.println(bo.getEid() + ", " + bo.getName() + ", " + bo.getAddress());
		}
		session.close();
		sf.close();
	}
}
