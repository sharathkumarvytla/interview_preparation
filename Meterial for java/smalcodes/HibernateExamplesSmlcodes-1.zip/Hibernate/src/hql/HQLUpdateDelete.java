package hql;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class HQLUpdateDelete {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		System.out.println("====== UPDATE OPERATION =========");
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("update BankBo b set b.balance =? where b.accno=?");
		query.setParameter(0, new Double(0));
		query.setParameter(1, new Integer(127));
		int rs = query.executeUpdate();
		tx.commit();
		System.out.println(rs + " :Rows are Updated");

		System.out.println("====== DELETE OPERATION =========");
		tx = session.beginTransaction();
		query = session.createQuery("delete from BankBo b where b.accno=?");
		query.setParameter(0, new Integer(133));
		rs = query.executeUpdate();
		System.out.println(rs + " :Rows are Updated");
		tx.commit();
		session.close();
	}
}
