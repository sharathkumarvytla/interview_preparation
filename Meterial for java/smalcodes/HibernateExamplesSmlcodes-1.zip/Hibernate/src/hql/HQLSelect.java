package hql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class HQLSelect {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		System.out.println("====1.Selecting Complete Object====== ");
		Query query = session.createQuery("Select b from BankBo b");
		List list = query.list();
		Iterator it = list.iterator();
		while (it.hasNext()) {
			BankBo bo = (BankBo) it.next();
			System.out.println("------------------------");
			System.out.println("ACC No : " + bo.getAccno());
			System.out.println("Name : " + bo.getAccname());
			System.out.println("Balance : " + bo.getBalance());

		}

		System.out.println("====2.Selecting Partial Object====== ");
		query = session.createQuery("Select b.accname, b.balance from BankBo b where b.accno=?");
		query.setParameter(0, new Integer(127));
		list = query.list();
		it = list.iterator();
		while (it.hasNext()) {
			Object o[] = (Object[]) it.next();
			System.out.println("Name : " + o[0]);
			System.out.println("Balance : " + o[1]);
		}
	}
}
