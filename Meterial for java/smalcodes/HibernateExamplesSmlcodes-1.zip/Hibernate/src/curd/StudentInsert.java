package curd;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class StudentInsert {

	public static void main(String[] args) {
		// 1.Load Configuration
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		// 2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		// 3.Create Transaction Object
		Transaction tx = session.beginTransaction();

 
		EmployeeBo ob1 = new EmployeeBo(12, "KARTHIK", "ONGOLE");
		session.save(ob1);
		tx.commit();

		tx.begin();
		EmployeeBo ob3 = new EmployeeBo(10, "NAG", "HYD");
		session.saveOrUpdate(ob3);
		tx.commit();

		EmployeeBo ob2 = new EmployeeBo(11, "PERSIST", "VIZAG");
		session.persist(ob2);

		System.out.println("Data Saved Sussesfully");
		session.close();
		sf.close();

	}
}
