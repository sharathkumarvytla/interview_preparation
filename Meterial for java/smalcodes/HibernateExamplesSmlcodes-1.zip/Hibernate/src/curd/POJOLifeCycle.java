package curd;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class POJOLifeCycle {

	public static void main(String[] args) {
		// 1.Load Configuration
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		// 2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//======1.Transient State START==========
		EmployeeBo bo = new EmployeeBo();
		bo.setEid(6);
		bo.setName("RAJESH");
		bo.setAddress("NEWYORK");
		//======1.Transient State END==========
		
		
		//======2.Persistent state START==========
		Transaction tx = session.beginTransaction();
		session.save(bo);
		tx.commit();		
		//======2.Persistent state END==========
		
		//========3.Detached State START========		 
		session.close();
		bo.setEid(7);
		bo.setName("MADHU");
		bo.setAddress("COLOMBO");
		//========3.Detached State END========	
		sf.close();

	}
}
