package curd;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class StudentSelect {

	public static void main(String[] args) { 
		
		//1.Load Configuration 
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		//2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		
		//3.Perform Operations
		Object ob = session.load(EmployeeBo.class, new Integer(1));
		EmployeeBo bo = (EmployeeBo) ob;
		
		System.out.println("SELECTED DATA\n ================");
		System.out.println("SNO : "+bo.getEid());
		System.out.println("NAME : "+bo.getName());
		System.out.println("ADDRESS : "+bo.getAddress());
	}
}
