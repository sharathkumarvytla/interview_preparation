package curd;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class StudentUpdate {

	public static void main(String[] args) {
		// 1.Load Configuration
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		// 2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//======Approach 1 ==========
		Transaction tx = session.beginTransaction();
		EmployeeBo ob1 = (EmployeeBo)session.load(EmployeeBo.class, new Integer(4));
		ob1.setAddress("VIJAYAWADA");
		tx.commit();
		
		//======Approach 2 ==========
		tx = session.beginTransaction();
		EmployeeBo ob2 = new EmployeeBo(new Integer(5), "ANANTH", "HYDERABAD");
		session.update(ob2);
		tx.commit();
		System.out.println("Update Completed!");
		 
		session.close();
		sf.close();

	}
}
