package onetomany;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OneToManyTest {
public static void main(String[] args) {
		 
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");	 
	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	
	Actor amir = new Actor();
	amir.setActorname("PRABAS");
	amir.setAge(36);
	amir.setActorid(106);
	
	Actor madhav = new Actor();
	madhav.setActorname("DAGGUBATI RANA");
	madhav.setAge(31);
	madhav.setActorid(107);
	
	Actor kareena = new Actor();
	kareena.setActorname("KATTAPPA");
	kareena.setAge(61);
	kareena.setActorid(108);
	
	Set<Actor> actors =new HashSet<Actor>();
	actors.add(amir);
	actors.add(madhav);
	actors.add(kareena);
	
	
	Movie movie = new Movie();
	movie.setTitle("BAAHUBALI");
	movie.setActors(actors);
	movie.setMid(501);
	
	Transaction tx = session.beginTransaction();
	session.save(movie);
	tx.commit();
	System.out.println("Succuess");
}
}
