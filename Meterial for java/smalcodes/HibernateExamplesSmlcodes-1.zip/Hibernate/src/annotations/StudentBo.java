package annotations;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="studenttable")
public class StudentBo {
	
@Id
@Column(name="sno")
@GeneratedValue(strategy=GenerationType.AUTO)
private int sno; //PRIMARY_KEY

@Column(name="name")
private String name;

@Column 		//By default it will take datamember name
private String address;

@Transient
private String iamnotindatabase; 
//This column not their in db

public int getSno() {
	return sno;
}

public void setSno(int sno) {
	this.sno = sno;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public StudentBo( String name, String address) {
	super();
 
	this.name = name;
	this.address = address;
}
public StudentBo() {
	super();	 
}



}
