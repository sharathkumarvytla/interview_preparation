package annotations;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class AnnotationExample {
	public static void main(String[] args) {

		Configuration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.cfg.xml");
 

		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction(); 
		System.out.println("1.Save Operation");
		System.out.println("===============================");

		StudentBo e1 = new StudentBo("SATYA", "HYD");
		StudentBo e2 = new StudentBo("RAM", "BANGLORE");
		StudentBo e3 = new StudentBo("KIRAN", "MUMBAI");
		session.save(e1);
		session.save(e2);
		session.save(e3);

		 
		System.out.println("2.Select Operation");
		System.out.println("===============================");
		List<StudentBo> ob = session.createQuery("FROM StudentBo").list();		 
		for (StudentBo e : ob) {
			System.out.println(e.getSno()+", "+e.getName()+", "+e.getAddress());
		}

		tx.commit();
		session.close();
		sf.close();

	}
}
