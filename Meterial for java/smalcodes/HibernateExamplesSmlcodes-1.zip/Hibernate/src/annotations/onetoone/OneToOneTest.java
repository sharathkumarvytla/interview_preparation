package annotations.onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class OneToOneTest {
public static void main(String[] args) {
	
	Configuration cfg = new AnnotationConfiguration();
	cfg.configure("hibernate.cfg.xml");


	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	 
	Car car = new Car();
	// Remember, we are using application generator for ids
	car.setId(2);
	car.setName("BENZ");
	car.setColor("RED");
	// Next, create an instance of engine and set values.
	// Note: you are not setting the id!
	Engine engine = new Engine();	
	engine.setModel("2209");
	engine.setSize("815KG");
	// Now we associate them together using the setter on the car
	 
	engine.setCar(car);
	// Lastly, we are persisting them
	
	Transaction tx = session.beginTransaction();
	session.save(car);
	session.save(engine);
	tx.commit();	
	System.out.println("Succuess");
}
}
