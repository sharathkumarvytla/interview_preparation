package annotations.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="engine")
public class Engine {
	
	@Id
	private int id = 0;
	
	@Column
	private String model = null;
	
	@Column
	private String size = null;
	
	
	@OneToOne(targetEntity=Car.class,cascade=CascadeType.ALL)
	 @JoinColumn(name="CAR_ID",referencedColumnName="CAR_ID")
	private Car car = null;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}
}
