package annotations.manytomany;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class ManyToManyTest {
public static void main(String[] args) {
		 
	Configuration cfg = new AnnotationConfiguration();
	cfg.configure("hibernate.cfg.xml");


	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	
	Student s1 = new Student();
	 s1.setStudentId(105);
	 s1.setStudentName("SACHIN");
	 
	 Student s2 = new Student();
	 s2.setStudentId(112);
	 s2.setStudentName("DHONI");
	 

	 Course c1 = new Course();
	 c1.setCourseId(303);
	 c1.setCourseName("DEVOPS");
	

	 Course c2 = new Course();
	 c2.setCourseId(304);
	 c2.setCourseName("HACKING");
	
	 Set<Student> students = new HashSet<Student>();
	 students.add(s1);
	 students.add(s2);
	 c1.setStudents(students);
	 c2.setStudents(students);
	 
	 
	 Set<Course> courses = new HashSet<Course>();
	 courses.add(c1);
	 courses.add(c2);
	 s1.setCourses(courses);
	 s2.setCourses(courses);
	 
	 
	 
	 
	
 
	Transaction tx = session.beginTransaction();
	session.save(c1);
	session.save(c2);
	tx.commit();
	System.out.println("Succuess");
}
}
