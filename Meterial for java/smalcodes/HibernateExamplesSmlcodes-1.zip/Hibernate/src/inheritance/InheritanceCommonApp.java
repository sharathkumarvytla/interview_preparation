package inheritance;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class InheritanceCommonApp {
	
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		Bike bike = new Bike();
		bike.setVid(101);
		bike.setBiketype("HONDA");
		bike.setPrice(50000);
		
		Car car = new Car();
		car.setVid(102);
		car.setCartype("MARUTHI");
		car.setPrice(600000);
		
		Transaction tx = session.beginTransaction();
		session.save(bike);		 
		session.save(car);
		tx.commit();
        session.close();
        factory.close();
		
	}

}
