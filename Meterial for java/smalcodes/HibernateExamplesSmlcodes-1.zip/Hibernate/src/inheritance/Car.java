package inheritance;

public class Car extends Vehicle {
	private String cartype;

	public String getCartype() {
		return cartype;
	}

	public void setCartype(String cartype) {
		this.cartype = cartype;
	}
}
