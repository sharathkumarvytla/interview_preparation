package onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OneToOneTest {
public static void main(String[] args) {
	
	// 1.Load Configuration
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	// 2.Create Session
	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	
	Car car = new Car();
	// Remember, we are using application generator for ids
	car.setId(1);
	car.setName("SWIFT");
	car.setColor("BLUE");
	// Next, create an instance of engine and set values.
	// Note: you are not setting the id!
	Engine engine = new Engine();	
	engine.setModel("2009");
	engine.setSize("85KG");
	// Now we associate them together using the setter on the car
	car.setEngine(engine);
	engine.setCar(car);
	// Lastly, we are persisting them
	
	Transaction tx = session.beginTransaction();
	session.save(car);
	session.save(engine);
	tx.commit();	
	System.out.println("Succuess");
}
}
