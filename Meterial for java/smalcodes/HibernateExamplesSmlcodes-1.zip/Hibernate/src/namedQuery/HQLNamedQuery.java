package namedQuery;

import java.util.Iterator;
import java.util.List;
import org.hibernate.*;
import org.hibernate.cfg.*;
import hql.BankBo;

public class HQLNamedQuery {

	public static void main(String[] args) {
		// 1.Load Configuration
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		// 2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		System.out.println("HQL-NamedQuery Example\n----------");
		Query qry = session.getNamedQuery("bankHQLQuery");
		qry.setParameter("bal", new Double(3000));
		List list = qry.list();
		Iterator it = list.iterator();
		while (it.hasNext()) {
			BankBo bo = (BankBo) it.next();
			System.out.println(bo.getAccname() + ", " + bo.getBalance());
		}		 
		session.close();
		sf.close();
	}
}
