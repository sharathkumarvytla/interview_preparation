package namedQuery;

import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;
import hql.BankBo;

public class NamedQueryDemo {

	public static void main(String[] args) {
		// 1.Load Configuration
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		// 2.Create Session
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Query qry = session.getNamedQuery("studentNativeQuery");
		List list = qry.list();
		Iterator it = list.iterator();
		while (it.hasNext()) {
			Object o[] = (Object[]) it.next();
			System.out.println(o[0] + ", " + o[1] + ", " + o[2]);
		}
		session.close();
		sf.close();
	}
}
