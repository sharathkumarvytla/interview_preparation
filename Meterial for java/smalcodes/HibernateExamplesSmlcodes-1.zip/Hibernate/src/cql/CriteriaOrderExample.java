package cql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import hql.BankBo;

public class CriteriaOrderExample {
	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(BankBo.class);
		Criterion cn = Restrictions.gt("balance", new Double(2000));
		criteria.add(cn);
		criteria.addOrder(Order.asc("balance"));
		List list = criteria.list();
		Iterator it = list.iterator();

		while (it.hasNext()) {
			BankBo bo = (BankBo) it.next();
			System.out.println(bo.getAccno() + ", "+ bo.getBalance());
		}
		session.close();
		factory.close();
	}
}
