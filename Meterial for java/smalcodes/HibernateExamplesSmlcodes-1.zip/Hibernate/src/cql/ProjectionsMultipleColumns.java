package cql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import hql.BankBo;

public class ProjectionsMultipleColumns {
	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(BankBo.class);

		Criterion cn = Restrictions.gt("balance", new Double(2000));
		criteria.add(cn);
		
		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("accname"));
		projectionList.add(Projections.property("balance"));
		
		criteria.setProjection(projectionList);			
		
		List list = criteria.list();		
		Iterator it = list.iterator();
		while (it.hasNext()) {
			Object[] o = (Object[]) it.next();
			System.out.println(o[0]+" : " +o[1]);
		}
		session.close();
		factory.close();
	}
}
