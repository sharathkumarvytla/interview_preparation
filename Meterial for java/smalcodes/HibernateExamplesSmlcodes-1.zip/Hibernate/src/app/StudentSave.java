package app;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class StudentSave {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		EmployeeBo bo = new EmployeeBo();
		bo.setEid(6);
		bo.setName("DILEEP");
		bo.setAddress("BANGLORE");

		Transaction tx = session.beginTransaction();
		session.save(bo);
		System.out.println("EMp Data saved successfully.....!!");
		tx.commit();
		session.close();
		factory.close();
	}
}
