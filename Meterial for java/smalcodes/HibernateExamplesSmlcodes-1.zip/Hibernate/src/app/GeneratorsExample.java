package app;

import org.hibernate.*;
import org.hibernate.cfg.*;

import bo.EmployeeBo;

public class GeneratorsExample {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		EmployeeBo bo = new EmployeeBo();
		//bo.setSno(100);
		bo.setName("uuid");
		bo.setAddress("uuid");

		Transaction tx = session.beginTransaction();
		session.save(bo);
		
		tx.commit();
		session.close();
		factory.close();
	}
}
