package manytoone;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ManyToOneTest {
public static void main(String[] args) {
		 
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");	 
	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	
	Actor amir = new Actor();
	amir.setActorname("AMIR KHAN");
	amir.setAge(42);
	amir.setActorid(101);
	
	Actor madhav = new Actor();
	madhav.setActorname("R. MADHAVAN");
	madhav.setAge(36);
	madhav.setActorid(102);
	
	Actor kareena = new Actor();
	kareena.setActorname("KAREENA KAPOOR");
	kareena.setAge(31);
	kareena.setActorid(103);
	
	Set<Actor> actors =new HashSet<Actor>();
	actors.add(amir);
	actors.add(madhav);
	actors.add(kareena);
	
	
	Movie movie = new Movie();
	movie.setTitle("3 IDIOTS");
	movie.setActors(actors);
	movie.setMid(501);
	
	Transaction tx = session.beginTransaction();
	session.save(movie);
	tx.commit();
	System.out.println("Succuess");
}
}
