package basic;

public class Operations {
	public int mul(int x, int y) {
		return x * y;
	}

	public int add(int x, int y) {
		return x + y;
	}

	public int sub(int x, int y) {
		return x-y;
	/*	if (x > y) {
			return x - y;
		} else if (y > x) {
			return y - x;
		} else {
			return 0;
		}*/
	}
	
	public int div(int x, int y) {
		
		/*if(y!= 0) {
			return x/y;
		}*/		
		return x/y;
	}
}
