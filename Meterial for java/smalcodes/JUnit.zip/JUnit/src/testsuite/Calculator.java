package testsuite;

public class Calculator {
	public int square(int x) {
		return x * x;
	}

	public int sum(int x, int y) {
		return x + y;
	}
}
