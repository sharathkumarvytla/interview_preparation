package junit;

public class Calculator {
	public int square(int x) {
		return x * x;
	}
	public int div(int a, int b) {
		return a / b;
	}
}
