package jsoup;
 
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document; 
public class JsoupGetMeta {
public static void main(String[] args) throws IOException {
	Document document = Jsoup.connect("http://www.smlcodes.com").get();
	String description = document.select("meta[name=description]").get(0).attr("content");  
    System.out.println("Meta Description : " + description);  
     
    String keywords = document.select("meta[name=keywords]").first().attr("content");  
    System.out.println("Meta Keyword : " + keywords);  
    
    String viewport = document.select("meta[name=viewport]").first().attr("content");  
    System.out.println("Meta viewport : " + viewport);  
}
}
