package jsoup;

import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JsoupGetAllImages {
	public static void main(String[] args) throws IOException {
		Document document = Jsoup.connect("http://www.smlcodes.com").get();
		Elements images = document.select("img[src~=(?i)\\.(png|jpe?g|gif)]");
		int i = 1;
		for (Element image : images) {
			System.out.println("\n\n===================\nIMAGE : " + i);
			System.out.println("Image Source : " + image.attr("src"));
			System.out.println("HEIGHT : " + image.attr("height"));
			System.out.println("WIDTH : " + image.attr("width"));
			System.out.println("ALT-Text : " + image.attr("alt"));
			i++;
		}
	}
}
