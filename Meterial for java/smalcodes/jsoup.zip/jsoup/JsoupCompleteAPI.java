package jsoup;

public class JsoupCompleteAPI {

}
