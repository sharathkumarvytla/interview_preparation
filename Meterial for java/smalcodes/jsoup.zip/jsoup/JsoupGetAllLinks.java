package jsoup;

import java.io.File;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JsoupGetAllLinks {
	public static void main(String[] args) throws IOException {
		Document document = Jsoup.parse(new File("D:/Small Codes/temp/sml.html"), "utf-8");
		Elements links = document.select("a[href]");
		for (Element link : links) {
			System.out.println("Link : " + link.attr("href"));
			System.out.println("Link Text : " + link.text());
		}
	}
}
