package jsoup;

import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class JsoupFromLocal {
	public static void main(String[] args) throws IOException {
		Document doc = Jsoup.parse(new File("D:\\Small Codes\\temp\\sml.html"), "UTF-8"); 
        String title = doc.title();  
        System.out.println("TITILE => " + title); 			 
	}
}
