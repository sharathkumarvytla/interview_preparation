package jsoup;

import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class JsoupFavIcon {
	public static void main(String[] args) throws IOException {
		String favicon = "Image Not Found";
		Document document = Jsoup.connect("http://www.smlcodes.com").get();
		Element element = document.head().select("link[href~=.*\\.(ico|png)]").first();
		if (element == null) {
			element = document.head().select("meta[itemprop=image]").first();
			if (element != null) {
				favicon = element.attr("content");
			}
		} else {
			favicon = element.attr("href");
		}

		System.out.println("FAV ICON Image URL Is ==>  " + favicon);
	}
}
