package jsoup;

import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JsoupForm {
	public static void main(String[] args) throws IOException {
		Document document = Jsoup.parse(new File("D:/Small Codes/temp/form.html"), "utf-8");
		Element formElement = document.getElementById("signup");
		Elements inputElements = formElement.getElementsByTag("input");
		for (Element inputElement : inputElements) {
			String key = inputElement.attr("name");
			String value = inputElement.attr("value");
			System.out.println("Element Name ==>  " + key + " \t Element value ==> " + value);
		}
	}
}
