package jsoup;

import java.io.File;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class JsoupLoadTypes {
	public static void main(String[] args) throws Exception {

		System.out.println("1.LOAD DOCUMENT FROM [URL] \n ----------------------");
		Document document = Jsoup.connect("http://www.smlcodes.com").get();
		System.out.println("Title : " + document.title());

		System.out.println("\n\n 2.LOAD DOCUMENT FROM [FILE] \n----------------------");
		document = Jsoup.parse(new File("D:/Small Codes/temp/sml.html"), "utf-8");
		System.out.println(document.title());

		System.out.println("\n\n 3.LOAD DOCUMENT FROM [String] \n----------------------");
		String html = "<html><head><title>SML Codes</title></head>"
				+ "<body><p>Programming Simplified</p></body></html>";
		document = Jsoup.parse(html);
		System.out.println(document.title());

	}
}
