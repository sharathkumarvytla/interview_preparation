package jsoup;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class JsoupFromWebsite {
	public static void main(String[] args) throws IOException {
	 
			//1.Open connection with website 
			Connection connection = Jsoup.connect("http://smlcodes.com");
			
			//2.parse the connected HTML page and save into Document
			Document document = connection.get();
			
			//3.write methods to get Elements
			String tit = document.title();
		 
	}
}
